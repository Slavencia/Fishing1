import pgzrun
import random


TITLE = "Рыбалка"
FPS = 60

mode = "menu"
bonus = Actor("button_", (100,470))
backg = Actor("background")
win = Actor("victoryc")
kubok = Actor("kubock2",(225,400))

backgallery = Actor("grassbackground")
button_gallery = Actor("button_", (350,470))
button_menu = Actor("button_", (200,470))
button_con = Actor("button_", (225,300))

karp = Actor("karp")
okun = Actor("okun")
goldfish = Actor("goldfish")
redfish = Actor("redfish")

karp_g = Actor("karp_ga",(100,100))
okun_g = Actor("okun_ga",(350,100))
goldfish_g = Actor("goldfish_g",(100,300))
redfish_g = Actor("redfish_g",(350,300))

karpies = []
okunies = []
goldfishies = []
redfishies = []

fish = []
j = 0
spisok_koord = [(100, 380), (210,380), (300,380), (50,425), (150,425), (250,425), (320,425), (370,425), (460,425), (540,425)]

map_level_2 = Actor("backg_2")

cell = Actor("sand")
cell1 = Actor("sand_2")
cell2 = Actor("dirt")
cell3 = Actor("dirt_2")
cell4 = Actor("dirt_3")
cell5 = Actor("water")
cell6 = Actor("grass_water")
cell7 = Actor("watergras")
float_ = Actor("float_air", (200,400))
float_w = Actor("floats_wat")


count = 0
left = 0

for i in range(2):
    x = random.randint(50, 400)
    y = random.randint(50, 330)
    goldfish = Actor("goldfish", (x, y))
    goldfishies.append(goldfish)
for i in range(2):
    x = random.randint(50, 400)
    y = random.randint(50, 330)
    karp = Actor("karp", (x, y))
    karpies.append(karp)
for i in range(2):
    x = random.randint(50, 400)
    y = random.randint(50, 330)
    okun = Actor("okun", (x, y))
    okunies.append(okun)
for i in range(2):
    x = random.randint(50, 400)
    y = random.randint(50, 330)
    redfish = Actor("redfish", (x, y))
    redfishies.append(redfish)

# 450 500    
    
size_w = 9 # Ширина поля в клетках
size_h = 10 # Высота поля в клетках
WIDTH = cell.width * size_w
HEIGHT = cell.height * size_h


my_map = [[5, 5, 5, 5, 5, 5, 5, 5, 5], 
          [5, 5, 5, 5, 5, 5, 5, 5, 5], 
          [5, 5, 5, 5, 5, 5, 5, 5, 5], 
          [5, 5, 5, 5, 5, 5, 5, 5, 5], 
          [5, 5, 5, 5, 5, 5, 5, 6, 5], 
          [6, 5, 6, 5, 6, 5, 6, 5, 5], 
          [5, 6, 6, 5, 5, 5, 7, 6, 5], 
          [6, 0, 1, 0, 1, 0, 1, 0, 6], 
          [2, 2, 2, 2, 2, 2, 2, 2, 2],
          [-1, -1, -1, -1, -1, -1, -1, -1, -1]]

          

def map_draw():
    
    
    
    for i in range(len(my_map)):
        for j in range(len(my_map[0])):
            if my_map[i][j] == 0:
                cell.left = cell.width*j
                cell.top = cell.height*i
                cell.draw()
            elif my_map[i][j] == 1:
                cell1.left = cell.width*j
                cell1.top = cell.height*i
                cell1.draw()
            elif my_map[i][j] == 2:
                cell2.left = cell.width*j
                cell2.top = cell.height*i
                cell2.draw()  
            elif my_map[i][j] == 3:
                cell3.left = cell.width*j
                cell3.top = cell.height*i
                cell3.draw()
            elif my_map[i][j] == 4:
                cell4.left = cell.width*j
                cell4.top = cell.height*i
                cell4.draw()    
            elif my_map[i][j] == 5:
                cell5.left = cell.width*j
                cell5.top = cell.height*i
                cell5.draw()
            elif my_map[i][j] == 6:
                cell6.left = cell.width*j
                cell6.top = cell.height*i
                cell6.draw()
            elif my_map[i][j] == 7:
                cell7.left = cell.width*j
                cell7.top = cell.height*i
                cell7.draw()    
def draw():    
    global count, mode, j

    if mode == "level_1":
        screen.fill("#2f3549")#Отрисовка рыб
        
        
        for i in range(len(okunies)):
                okunies[i].draw()
        for i in range(len(karpies)):
                karpies[i].draw()
        for i in range(len(goldfishies)):
                goldfishies[i].draw()
        for i in range(len(redfishies)):
                redfishies[i].draw()
        map_draw()
        screen.draw.text("Очки", center=(30, 475), color = 'white', fontsize = 20)
        screen.draw.text(count, center=(75, 475), color = 'white', fontsize = 20)
#Анимация    
    if float_.collidelist(okunies) == 1 and float_.image == "floats_wat":
        float_.y -= 2
        animate(float_, tween='bounce_start_end', duration=0.7, y=float_.y + 4 )
        
    if float_.collidelist(karpies) == 1 and float_.image == "floats_wat":
        float_.y -= 2
        animate(float_, tween='bounce_start_end', duration=0.7, y=float_.y + 4 )
        
    if float_.collidelist(goldfishies) == 1 and float_.image == "floats_wat":
        float_.y -= 2
        animate(float_, tween='bounce_start_end', duration=0.7, y=float_.y + 4 )
        
    if float_.collidelist(redfishies) == 1 and float_.image == "floats_wat":
        float_.y -= 2
        animate(float_, tween='bounce_start_end', duration=0.7, y=float_.y + 4 )    
                    
    #Попловок
    float_.draw()
    for i in range(len(fish)):
        fish[i].draw() 
            
    if mode == "menu":
        map_level_2.draw()
        bonus.draw()        
        screen.draw.text("Начать", center=(100, 465), color = 'black', fontsize = 25)   
        button_gallery.draw()
        screen.draw.text("Коллекция", center=(350, 465), color="black", fontsize = 25)
        
        
    elif mode == 'gallery':    
        backgallery.draw()
        karp_g.draw()
        okun_g.draw()
        goldfish_g.draw()
        redfish_g.draw()
        button_menu.draw()
        screen.draw.text("Вернуться в меню", center=button_menu.pos, color="black", fontsize = 20)
    if count == 10:
        screen.fill("#2f3549")
        button_con.draw()
        screen.draw.text("Продолжить", center=(225,300), color="black", fontsize = 20)
        screen.draw.text("Вы прошли первый уровень", center=(225,90), color="white", fontsize = 30)
        screen.draw.text("Продолжим на 2 уровне?", center=(225,150), color="white", fontsize = 20)
        
    if mode == "level_2":
        
        for i in range(len(okunies)):
            okunies[i].draw()
        for i in range(len(karpies)):
            karpies[i].draw()
        for i in range(len(goldfishies)):
            goldfishies[i].draw()
        for i in range(len(redfishies)):
            redfishies[i].draw()
        map_level_2.draw()
        screen.draw.text("Очки", center=(30, 475), color = 'white', fontsize = 20)
        screen.draw.text(count, center=(75, 475), color = 'white', fontsize = 20)

    #Попловок
    float_.draw()
    for i in range(len(fish)):
        fish[i].draw() 
            
    if mode == "menu":
        backg.draw()
        bonus.draw() 
        screen.draw.text("Итоговый проект", center=(370, 10), color = 'yellow', fontsize = 20)
        screen.draw.text("Копылова Вячеслава", center=(375, 30), color = 'yellow', fontsize = 15)
        screen.draw.text("Школа Kodland", center=(395, 50), color = 'yellow', fontsize = 15)
        screen.draw.text("25.05.2024", center=(410, 70), color = 'yellow', fontsize = 15)
        screen.draw.text("Начать", center=(100, 465), color = 'black', fontsize = 25)   
        button_gallery.draw()
        screen.draw.text("Коллекция", center=(350, 465), color="black", fontsize = 25)
    
    elif mode == 'gallery':    
        backgallery.draw()
        karp_g.draw()
        okun_g.draw()
        goldfish_g.draw()
        redfish_g.draw()
        button_menu.draw()
        screen.draw.text("Вернуться в меню", center=button_menu.pos, color="black", fontsize = 20)
    elif count == 15:
        win.draw()
        kubok.draw()
        screen.draw.text("Победа", center=(225, 50), color = 'red', fontsize = 60)
        screen.draw.text("Вы выловили всю рыбу🐟", center=(230, 480), color = 'green', fontsize = 30)
        
def on_mouse_move(pos):#Поплавок движение за мышкой
    if left != 1:
        float_.pos = pos
    
def on_mouse_down(button, pos):
    #Обработка кликов 92-100
    global left, mode
    if button == mouse.LEFT:
        if bonus.collidepoint(pos) and mode == "menu" or mode == "gallery":
            mode = "level_1"
    
        elif button_gallery.collidepoint(pos) and mode == "menu":
            mode = 'gallery'
            
        elif button_menu.collidepoint(pos) and mode == "menu":
            mode = 'menu'   
        
        elif button_con.collidepoint(pos) and count == 10:
            mode = "level_2"
            
    if button == mouse.LEFT:
        float_.image = "floats_wat"
        if left == 0:
            left = 1
        else:
            left = 0
            float_.image = "float_air"
        float_.pos = pos
    
def on_key_down(key):
    global count, mode, j, fish
    if mode == "level_1":
        if float_.collidelist(okunies) != -1 and float_.image == "floats_wat":  
            if keyboard.enter:
                index = float_.collidelist(okunies)
                count += 1
                fis = Actor("okun")
                fis.pos = spisok_koord[j]
                j += 1
                fish.append(fis)
                okunies.pop(index)
                
        if float_.collidelist(karpies) != -1 and float_.image == "floats_wat":    
           if keyboard.enter:
                index = float_.collidelist(karpies)
                count += 1 
                fid = Actor("karp")
                fid.pos = spisok_koord[j]
                j += 1
                fish.append(fid)
                karpies.pop(index)
                
        if float_.collidelist(goldfishies) != -1 and float_.image == "floats_wat":
            if keyboard.enter:
                index = float_.collidelist(goldfishies)
                count += 2
                fit = Actor("goldfish")
                fit.pos = spisok_koord[j]
                j += 1
                fish.append(fit)
                goldfishies.pop(index)
        
        if float_.collidelist(redfishies) != -1 and float_.image == "floats_wat":
            if keyboard.enter:
                index = float_.collidelist(redfishies)
                count += 1
                fiss = Actor("redfish")
                fiss.pos = spisok_koord[j]
                j += 1
                fish.append(fiss)
                redfishies.pop(index)
    
    if mode == "level_2":
        if float_.collidelist(okunies) != -1 and float_.image == "floats_wat":  
            if keyboard.enter:
                index = float_.collidelist(okunies)
                count += 1
                fis = Actor("okun")
                fis.pos = spisok_koord[j]
                j += 1
                fish.append(fis)
                okunies.pop(index)
                
        if float_.collidelist(karpies) != -1 and float_.image == "floats_wat":    
           if keyboard.enter:
                index = float_.collidelist(karpies)
                count += 1 
                fid = Actor("karp")
                fid.pos = spisok_koord[j]
                j += 1
                fish.append(fid)
                karpies.pop(index)
                
        if float_.collidelist(goldfishies) != -1 and float_.image == "floats_wat":
            if keyboard.enter:
                index = float_.collidelist(goldfishies)
                count += 2
                fit = Actor("goldfish")
                fit.pos = spisok_koord[j]
                j += 1
                fish.append(fit)
                goldfishies.pop(index)
        
        if float_.collidelist(redfishies) != -1 and float_.image == "floats_wat":
            if keyboard.enter:
                index = float_.collidelist(redfishies)
                count += 1
                fiss = Actor("redfish")
                fiss.pos = spisok_koord[j]
                j += 1
                fish.append(fiss)
                redfishies.pop(index)
        if count == 10:
            mode = "level_2"
            j = 0
            x = random.randint(50, 400)
            y = random.randint(50, 330)
            goldfish = Actor("goldfish", (x, y))
            goldfishies.append(goldfish)
    
            x = random.randint(50, 400)
            y = random.randint(50, 330)
            karp = Actor("karp", (x, y))
            karpies.append(karp)
    
            x = random.randint(50, 400)
            y = random.randint(50, 330)
            okun = Actor("okun", (x, y))
            okunies.append(okun)
    
            x = random.randint(50, 400)
            y = random.randint(50, 330)
            redfish = Actor("redfish", (x, y))
            redfishies.append(redfish) 
    
            fish = []
    
pgzrun.go()        